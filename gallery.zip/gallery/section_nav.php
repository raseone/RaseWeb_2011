  <div id="button_trans_round"><a href="logos.php">Logo Design Portfolio</a></div>
  <div id="button_trans_round"><a href="fliers.php">Flier Design Portfolio</a></div>
  <div id="button_trans_round"><a href="album_covers.php">Album Cover Portfolio</a></div>
  <div id="button_trans_round"><a href="../index.htm">Business Card Portfolio</a></div>
  <div id="button_trans_round"><a href="../index.htm">Photography Portfolio</a></div>
  <div id="button_trans_round"><a href="clothing_portfolio.php">Clothing Design Portfolio</a></div>
  <div id="button_trans_round"><a href="pre_digital_portfolio.php">Pre-Digital Portfolio</a></div>
  <div id="button_trans_round"><a href="web_design.php">Web Design Portfolio</a></div>
